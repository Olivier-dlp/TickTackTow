﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TIckTackTow
{
    class Setting
    {
        public Setting(ConsoleColor Writtingcolor, ConsoleColor BackCollor, string title, int height, int width)
        {
            
            Console.ForegroundColor = Writtingcolor;
            Console.BackgroundColor = BackCollor;
            Console.Title = title;
            Console.WindowHeight = height;
            Console.WindowWidth = width;
            
        }


    }
}
